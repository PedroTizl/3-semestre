package br.com.caelum.contas.main;

import br.com.caelum.contas.Conta;
import br.com.caelum.contas.ContaCorrente;
import br.com.caelum.contas.ContaPoupanca;
import br.com.caelum.contas.GerenciarTributos;

import java.util.Scanner;

public class teste_da_conta {
	static Scanner s = new Scanner(System.in);

	public static void main(String[] args) {
		
		ContaCorrente c2 = new ContaCorrente();
		ContaPoupanca c3 = new ContaPoupanca();
		System.out.println(Conta.getidentificador());
		System.out.println("Selecione o tipo de conta 1 Para Conta Corrente e 2 para Conta Poupan�a:");
		int TipoConta = s.nextInt();
		if (TipoConta == 1) {

			System.out.println("Conta Corrente");
			c2.setTitular("Pedro");
			c2.setnumero(190);
			c2.setagencia("12345-6");
			c2.setdata_de_abertura("15/02/2020");
			c2.deposita(50.0);
			c2.saca(10.0);
			System.out.println("\n " + c2.recuperaDadosParaImpressao());
			System.out.println("rendimento mensal:" + c2.calculaRendimento());
			System.out.println("Saldo atual:R$" +  GerenciarTributos.getTotalimpostos());
			System.out.println("tipo de conta:" + ContaCorrente.getTipo());
			
		}
		if (TipoConta == 2) {
			System.out.println("Conta Poupan�a");
			c3.setTitular("Bruno");
			c3.setnumero(192);
			c3.setagencia("12345-6");
			c3.setdata_de_abertura("15/02/2020");
			System.out.println("Saldo atual :R$" + ContaPoupanca.getSaldo);
			c3.deposita(50.0);
			c3.saca(10.0);
			c3.transfere(c2,  5.0);
			System.out.println("\n " + c3.recuperaDadosParaImpressao());
			System.out.println("rendimento mensal:" + c3.calculaRendimento());
			System.out.println("tipo de conta:" + ContaPoupanca.getTipo);
			
		}
		if (TipoConta != 1 && TipoConta != 2) {
			System.out.println("Selecione um numero valido!!");
		}

		
		
	


	}

}
