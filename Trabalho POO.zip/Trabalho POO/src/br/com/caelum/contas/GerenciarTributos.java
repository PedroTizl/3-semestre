//Pedro Henrique Tizl 00100142
//Vin�cius Marcelo    00099324 
package br.com.caelum.contas;

public class GerenciarTributos {
	public static double getTotalimpostos;
	
	private static double total;
	public void calculaImpostos(Conta impostos){
		total=0;
		total+=ContaCorrente.getValorImposto+SeguroDeVida.getValorImposto;
		
		   
		 }
	
	public static double getTotalimpostos() {
		   return total;
		 }

}
