//Pedro Henrique Tizl 00100142
//Vin�cius Marcelo    00099324 
package br.com.caelum.contas;

public interface impostos {
	   public double getValorImposto();

	double getSaldo();
	 }