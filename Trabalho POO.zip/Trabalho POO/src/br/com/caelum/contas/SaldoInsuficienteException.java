//Pedro Henrique Tizl 00100142
//Vin�cius Marcelo    00099324 
package br.com.caelum.contas;

public class SaldoInsuficienteException extends RuntimeException {    

    public SaldoInsuficienteException(String message) {
        super(message);
    }
    
}