//Pedro Henrique Tizl 00100142
//Vin�cius Marcelo    00099324 

package br.com.caelum.contas;
public  abstract class Conta {
	protected String Titular;
	protected int numero;
	protected String agencia;
	protected static  double saldo;
	protected String data_de_abertura;
	
	
	public void saca(double valor) {
		if (saldo < valor) {
			throw new SaldoInsuficienteException("Saldo Insuficiente," +  
                    "tente um valor menor");
		} else {
			System.out.println("Sacado com sucesso: " + valor);
			saldo = saldo - valor;
			System.out.println("Saldo atual:R$"+saldo);
		}
	}

	public void deposita(double valor) {

		if (valor < 0) {
			throw new IllegalArgumentException("Voce n�o pode depositar valores negativos");
		} else {

			System.out.println("Depositado com sucesso: " + valor);
			saldo = saldo + valor;
			System.out.println("Saldo atual:R$"+saldo);
		}
	}

	public double calculaRendimento() {
		double saldorend = saldo * 0.1;
		return saldorend;

	}

	public String recuperaDadosParaImpressao() {
		String dados = "Titular:" + this.Titular;
		dados += "\nnumero:" + this.numero;
		dados += "\nagencia:" + this.agencia;
		dados += "\nsaldo:" + this.saldo;
		dados += "\ndata de abertura:" + this.data_de_abertura;
		return dados;

	}

	public double getSaldo() {
		return saldo;
	}

	public void setTitular(String titular) {
		this.Titular = titular;
	}

	public String getTitular() {
		return this.Titular;
	}

	public int getnumero() {
		return this.numero;
	}

	public void setnumero(int numero) {
		this.numero = numero;
	}

	public void setagencia(String agencia) {
		this.agencia = agencia;
	}

	public String getagencia() {
		return this.agencia;
	}

	public void setdata_de_abertura(String data_de_abertura) {
		this.data_de_abertura = data_de_abertura;
	}

	public String getdata_de_abertura() {
		return this.data_de_abertura;
	}
	
	
	
	public  static String getTipo() {
	
		return null;
	}
	
	public void transfere(Conta destino, double valor) {
		if (saldo>valor) {
        this.saldo = this.saldo - valor;
        destino.saldo = destino.saldo + valor;
        System.out.println("Transferido com sucesso :R$"+valor+" para conta "+destino);
		}
		else {
			
		 System.out.println("Voce n�o tem saldo o suficiente para realizar a transferencia ");
		}
    }
	

	
	


	protected static int identificador;
    

	public Conta() {
    	
        Conta.identificador = Conta.identificador+1  ;
    }
    public static int getidentificador() {
    	System.out.println("Quantidade de contas criadas");
        return Conta.identificador;
    }

	public double getValorImposto() {
		
		return 0;
	}
    

	
    
	
    
}
