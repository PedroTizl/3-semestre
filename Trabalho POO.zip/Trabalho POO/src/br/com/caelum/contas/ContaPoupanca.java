//Pedro Henrique Tizl 00100142
//Vin�cius Marcelo    00099324 
package br.com.caelum.contas;

public class ContaPoupanca extends Conta {
	
	
	public static double getSaldo;
	public static String getTipo;

	@Override
	public double calculaRendimento() {
		double saldorend = saldo * 0.3;
		return saldorend;

		
	}
	public void deposita(double valor) {

		if (valor < 0) {
			System.out.println("Voce n�o pode depositar valores negativos");
		} else {
double saldoantesdeposito=saldo*0.3;
double saldodpsdeposito=(saldo+valor)*0.3;
			System.out.println("Depositado com sucesso:R$ " + valor);
			System.out.println("Rendimento antes do deposito:R$ " + saldoantesdeposito );
			System.out.println("Rendimento depois do deposito:R$ " + saldodpsdeposito );
			
			saldo = saldo + valor;
			System.out.println("Saldo atual:R$"+saldo);
		}
	}
	public double getSaldo() {
		
	
		return  saldo  ;

	}

	public void setTitular(String titular) {
		this.Titular = titular;
	}

	public String getTitular() {
		return this.Titular;
	}

	public int getnumero() {
		return this.numero;
	}

	public void setnumero(int numero) {
		this.numero = numero;
	}

	public void setagencia(String agencia) {
		this.agencia = agencia;
	}

	public String getagencia() {
		return this.agencia;
	}

	public void setdata_de_abertura(String data_de_abertura) {
		this.data_de_abertura = data_de_abertura;
	}

	public String getdata_de_abertura() {
		return this.data_de_abertura;
	}
	
	 public static String getTipo() {
		 
		 return "Conta Poupan�a";
     }
	
	
}
