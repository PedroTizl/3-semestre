//Pedro Henrique Tizl 00100142
//Vin�cius Marcelo    00099324 
package br.com.caelum.contas;

public class SeguroDeVida implements impostos {
	public static double getValorImposto;
    private double valor;
    
    private String titular;
    
    private int numeroApolice;

    public double getValorImposto() {
        return 42 + this.valor * 0.02;
        
    }
    public String getTipo(){
        return "Seguro de Vida";
    }
	@Override
	public double getSaldo() {
		// TODO Auto-generated method stub
		return 0;
	}
}
